package rechnungen;

import java.io.File;
import javax.xml.bind.*;

public class TestClass {

	public static void main(String[] args) throws JAXBException {

		JAXBContext context = JAXBContext.newInstance("rechnungen");
		Unmarshaller unmarshaller = context.createUnmarshaller();
		MultCheck checks = (MultCheck) JAXBIntrospector.getValue(unmarshaller.unmarshal(new File("Aufgabe-4.xml")));
		String str = "";
		for (Check check : checks.getRechnung()) {

			str = str + "\n-------------------------------------------------------- \n";
			str = str + check.getAnschriftEmpfaenger().get(0).getAnrede().get(0) + " "
					+ check.getAnschriftEmpfaenger().get(0).getName().get(0) + "."
					+ " \nBitte zahlen Sie endlich den geforderten Betrag \nvon "
					+ check.getEntgeldFuerDieLieferung().get(0).getNettobetrag().get(0) + " "
					+ check.getEntgeldFuerDieLieferung().get(0).getWaehrung().get(0) + " auf das Konto\n";
			if (!check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getInstitutsname().isEmpty()) {
				str = str + check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getInstitutsname().get(0);
			}
			if (!check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getKontonummer().isEmpty()) {
				str = str + ", "
						+ check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getKontonummer().get(0);
			}
			if (!check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getIban().isEmpty()) {
				str = str + ", " + check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getIban().get(0);
			}
			if (!check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getBic().isEmpty()) {
				str = str + ", " + check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getBic().get(0);
			}
			if (!check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getBlz().isEmpty()) {
				str = str + ", " + check.getZahlungsmoeglichkeiten().get(0).getZahlungsart1().get(0).getBlz().get(0);
			}
			str = str + " ein.\n";
			if (!check.getAnschriftAbsender().get(0).getTelefon().isEmpty()) {
				str = str
						+ "Falls Sie trotzdem noch unversch�mt genug sind \nund Fragen haben, dann k�nnen Sie mich jederzeit\nunter "
						+ check.getAnschriftAbsender().get(0).getTelefon().get(0) + " erreichen.\n";
			}

			str = str + "Hochachtungsvoll\n" + check.getAnschriftAbsender().get(0).getName().get(0) + ".";
			str = str + "\n-------------------------------------------------------- \n";
		}
		System.out.println(str);
	}
}
